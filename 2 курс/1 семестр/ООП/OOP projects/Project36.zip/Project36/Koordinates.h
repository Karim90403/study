#pragma once
#include "Shape.h"

class Koordinates
{
public:
	int x, y;
	Koordinates();
	Koordinates(int x1, int y1);
	~Koordinates();
};

