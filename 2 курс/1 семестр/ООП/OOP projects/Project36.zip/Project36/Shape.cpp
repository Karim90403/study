#include "Shape.h"

Shape::Shape() = default;

Shape::~Shape() {
}

void Shape::print(){}
