#include "Koordinates.h"

Koordinates::Koordinates() = default;

Koordinates::Koordinates(int x1, int y1)
{
	x = x1; y = y1;
}

Koordinates::~Koordinates() {

}
