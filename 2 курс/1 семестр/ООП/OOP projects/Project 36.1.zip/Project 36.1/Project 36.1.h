#pragma once

#include "resource.h"
#include "PolyLineShape.h"
