#pragma once
class P
{
};

