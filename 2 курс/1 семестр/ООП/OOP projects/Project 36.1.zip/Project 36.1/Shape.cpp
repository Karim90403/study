#include "Shape.h"

Shape::Shape() {};

Shape::~Shape() {}

void Shape::print(HDC* hdc, int sx, int sy) {}