#include "Muzafarov.h"

Muzafarov::Muzafarov() {}
void Muzafarov::copy(vector<Muzafarov*>& v) {}
Muzafarov::Muzafarov(const Muzafarov& obj) {}
void Muzafarov::print() {}
Muzafarov::~Muzafarov() {}