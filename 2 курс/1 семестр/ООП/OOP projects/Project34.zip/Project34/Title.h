#pragma once
#include "Word.h"

class Title : public Word
{
};

