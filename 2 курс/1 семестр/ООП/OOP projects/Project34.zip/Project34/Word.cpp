#include "Word.h"

void Word::push(wstring word) {
	v.push_back(word);
}